# Taller JUnit: Calidad de Software en Java

Este proyecto resuelve las **Actividades 1–4** del taller. Incluye un proyecto Maven con JUnit 5 y pruebas para una clase `Calculadora`.

## Requisitos
- JDK 11+
- Maven 3.8+
- IDE (IntelliJ IDEA / Eclipse) – opcional

## Cómo ejecutar
```bash
mvn -v              # verificar Maven
mvn test            # ejecutar las pruebas
```
Los reportes JUnit XML se generan en `target/surefire-reports/`.

## Estructura
```
taller-junit-calidad-java/
  ├─ pom.xml
  └─ src
     ├─ main/java/com/example/calc/Calculadora.java
     └─ test/java/com/example/calc/CalculadoraTest.java
```

## Actividad 4: Análisis de resultados
- Todas las pruebas deben pasar.
- Si falla alguna, corrige la implementación en `Calculadora` o el caso de prueba y vuelve a correr `mvn test`.
