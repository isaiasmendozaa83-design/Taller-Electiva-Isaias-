package com.example.calc;

/**
 * Clase Calculadora con operaciones básicas y algunas validaciones.
 */
public class Calculadora {

    public int sumar(int a, int b) {
        return a + b;
    }

    public int restar(int a, int b) {
        return a - b;
    }

    public int multiplicar(int a, int b) {
        return a * b;
    }

    public double dividir(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("No se puede dividir por cero");
        }
        return a / b;
    }

    public double potencia(double base, double exponente) {
        return Math.pow(base, exponente);
    }

    public double raizCuadrada(double x) {
        if (x < 0) {
            throw new IllegalArgumentException("No se puede sacar raíz de número negativo");
        }
        return Math.sqrt(x);
    }
}
