package com.example.calc;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;
import static org.assertj.core.api.Assertions.assertThat;

@DisplayName("Pruebas unitarias para Calculadora")
class CalculadoraTest {

    private final Calculadora calc = new Calculadora();

    @Test
    @DisplayName("Suma básica")
    void testSumar() {
        assertEquals(7, calc.sumar(3, 4));
        assertThat(calc.sumar(-1, 1)).isZero();
    }

    @ParameterizedTest(name = "restar({0}, {1}) = {2}")
    @CsvSource({
            "3, 1, 2",
            "10, 5, 5",
            "-2, -2, 0",
            "0, 3, -3"
    })
    void testRestarParametrizado(int a, int b, int esperado) {
        assertEquals(esperado, calc.restar(a, b));
    }

    @Test
    void testMultiplicar() {
        assertAll(
            () -> assertEquals(0, calc.multiplicar(0, 100)),
            () -> assertEquals(15, calc.multiplicar(3, 5)),
            () -> assertEquals(-12, calc.multiplicar(-3, 4))
        );
    }

    @Test
    void testDividir() {
        assertEquals(2.5, calc.dividir(5, 2), 1e-9);
    }

    @Test
    void testDividirPorCeroLanzaExcepcion() {
        ArithmeticException ex = assertThrows(ArithmeticException.class,
                () -> calc.dividir(10, 0));
        assertThat(ex).hasMessageContaining("cero");
    }

    @Nested
    @DisplayName("Operaciones avanzadas")
    class Avanzadas {
        @Test
        void testPotencia() {
            assertEquals(8, calc.potencia(2, 3), 1e-9);
        }

        @Test
        void testRaizCuadrada() {
            assertEquals(5, calc.raizCuadrada(25), 1e-9);
        }

        @Test
        void testRaizNegativa() {
            IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                    () -> calc.raizCuadrada(-1));
            assertThat(ex.getMessage()).contains("negativo");
        }
    }
}
